import unittest

from voltronic_charger.main import _identify
from voltronic_charger.protocol import ProtocolError


class FakeClient:
    def __init__(self, responses):
        self.responses = responses
        self.commands = []

    def query(self, command):
        self.commands.append(command)
        response = self.responses[command]
        if isinstance(response, Exception):
            raise response
        return response


class MainIdentificationTest(unittest.TestCase):
    def test_live_identity_and_qvfw2_fallback(self):
        client = FakeClient(
            {
                "QPI": "(PI30",
                "QMN": "(KING-5000",
                "QID": "(96332108100916",
                "QVFW": ProtocolError("NAK"),
                "QVFW2": "(VERFW2:00000.00",
            }
        )
        self.assertEqual(
            {
                "protocol_id": "PI30",
                "inverter_model": "KING-5000",
                "serial_number": "96332108100916",
                "firmware": "VERFW2:00000.00",
            },
            _identify(client),
        )
        self.assertEqual(["QPI", "QMN", "QID", "QVFW", "QVFW2"], client.commands)

    def test_wrong_protocol_is_rejected_before_publication(self):
        client = FakeClient({"QPI": "(PI18"})
        with self.assertRaises(ProtocolError):
            _identify(client)

    def test_wrong_model_is_rejected_before_publication(self):
        client = FakeClient({"QPI": "(PI30", "QMN": "(OTHER"})
        with self.assertRaises(ProtocolError):
            _identify(client)


if __name__ == "__main__":
    unittest.main()
