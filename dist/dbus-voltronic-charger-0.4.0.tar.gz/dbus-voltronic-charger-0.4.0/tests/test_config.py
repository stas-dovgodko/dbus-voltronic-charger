import os
import tempfile
import unittest

from voltronic_charger.config import load_config


BASE = """[serial]
port = {port}
baudrate = 2400
timeout = 2
command_delay = {command_delay}
[protocol]
profile = {profile}
publish_battery_charging_current = {publish}
[device]
model = Voltronic King II 5000
custom_name = King II
device_instance = 40
service_name = com.victronenergy.charger.voltronic_king2
[driver]
poll_interval = 5
failure_threshold = 3
[control]
allow_current_limit_writes = {allow_writes}
parallel_unit = {parallel_unit}
"""


class ConfigTest(unittest.TestCase):
    def _load(self, **values):
        content = BASE.format(
            port=values.get("port", "/dev/serial/by-id/example"),
            command_delay=values.get("command_delay", 0.5),
            profile=values.get("profile", "pi30"),
            publish=str(values.get("publish", True)).lower(),
            allow_writes=str(values.get("allow_writes", False)).lower(),
            parallel_unit=values.get("parallel_unit", 0),
        )
        if values.get("missing_instance"):
            content = content.replace("device_instance = 40", "device_instance =")
        handle = tempfile.NamedTemporaryFile("w", delete=False)
        try:
            handle.write(content)
            handle.close()
            return load_config(handle.name)
        finally:
            os.unlink(handle.name)

    def test_confirmed_profile_and_current_publication_load(self):
        config = self._load()
        self.assertEqual("pi30", config.protocol.profile)
        self.assertTrue(config.protocol.publish_battery_charging_current)
        self.assertEqual(0.5, config.serial.command_delay)

    def test_current_publication_can_be_disabled(self):
        config = self._load(publish=False)
        self.assertFalse(config.protocol.publish_battery_charging_current)

    def test_configured_port_is_preserved_verbatim(self):
        config = self._load(port="/dev/ttyUSB1")
        self.assertEqual("/dev/ttyUSB1", config.serial.port)

    def test_port_is_required(self):
        with self.assertRaises(ValueError):
            self._load(port="")

    def test_device_instance_is_required(self):
        with self.assertRaises(ValueError):
            self._load(missing_instance=True)

    def test_negative_command_delay_is_rejected(self):
        with self.assertRaises(ValueError):
            self._load(command_delay=-0.1)

    def test_current_limit_writes_are_explicitly_opt_in(self):
        self.assertFalse(self._load().control.allow_current_limit_writes)
        self.assertTrue(
            self._load(allow_writes=True).control.allow_current_limit_writes
        )

    def test_parallel_unit_is_validated(self):
        with self.assertRaises(ValueError):
            self._load(parallel_unit=10)

    def test_missing_control_section_defaults_to_read_only(self):
        content = BASE.format(
            port="/dev/ttyUSB1",
            command_delay=0.5,
            profile="pi30",
            publish="true",
            allow_writes="false",
            parallel_unit=0,
        ).split("[control]", 1)[0]
        handle = tempfile.NamedTemporaryFile("w", delete=False)
        try:
            handle.write(content)
            handle.close()
            config = load_config(handle.name)
        finally:
            os.unlink(handle.name)
        self.assertFalse(config.control.allow_current_limit_writes)
        self.assertEqual(0, config.control.parallel_unit)


if __name__ == "__main__":
    unittest.main()
