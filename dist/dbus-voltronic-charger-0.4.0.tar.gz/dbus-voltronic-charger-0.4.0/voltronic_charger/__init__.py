"""Read-only Voltronic charger telemetry bridge."""

__version__ = "0.4.0"
