"""Venus charger publisher for the confirmed King II PI30 profile."""

from __future__ import annotations

import os
import platform
import sys

from . import __version__
from .config import DriverConfig
from .models import ChargeCurrentCapabilities, Pi30Status


CHARGER_STATE_OFF = 0
CHARGER_STATE_POWER_SUPPLY = 11


def _load_vedbus():
    velib_path = os.environ.get(
        "VELIB_PYTHON", "/opt/victronenergy/dbus-systemcalc-py/ext/velib_python"
    )
    if velib_path not in sys.path:
        sys.path.insert(0, velib_path)
    try:
        from vedbus import VeDbusService
    except ImportError as exc:
        raise RuntimeError(
            "unable to import Victron velib_python from {}".format(velib_path)
        ) from exc
    return VeDbusService


def _format_value(unit: str, decimals: int):
    def formatter(_path, value):
        if value is None:
            return ""
        return ("{:0." + str(decimals) + "f} {} ").format(value, unit).strip()

    return formatter


class ChargerDbusService:
    def __init__(
        self,
        config: DriverConfig,
        serial_number=None,
        firmware=None,
        protocol_id=None,
        inverter_model=None,
        capabilities: ChargeCurrentCapabilities = None,
        bus=None,
    ):
        VeDbusService = _load_vedbus()
        self.config = config
        if bus is None:
            try:
                import dbus
            except ImportError:
                pass
            else:
                try:
                    bus = dbus.SystemBus()
                except Exception:
                    pass
        self._service = VeDbusService(
            config.device.service_name, bus=bus, register=False
        )
        self._add("/Mgmt/ProcessName", "voltronic-charger")
        self._add("/Mgmt/ProcessVersion", "Python {}".format(platform.python_version()))
        self._add("/Mgmt/Connection", "RS232 {}".format(config.serial.port))
        self._add("/DeviceInstance", config.device.device_instance)
        self._add("/ProductName", config.device.model)
        self._add("/CustomName", config.device.custom_name)
        self._add("/FirmwareVersion", firmware)
        self._add("/Serial", serial_number)
        self._add("/DriverVersion", __version__)
        self._add("/Connected", 0)
        self._add("/Dc/0/Voltage", None, _format_value("V", 2))
        self._add("/Dc/0/Current", None, _format_value("A", 1))
        self._add("/Dc/0/Power", None, _format_value("W", 0))
        self._add("/State", None)
        self._add("/ErrorCode", None)
        self._add("/Protocol/Profile", config.protocol.profile)
        self._add("/Protocol/Id", protocol_id)
        self._add("/Protocol/Model", inverter_model)
        self._add(
            "/Protocol/CurrentPublished",
            int(config.protocol.publish_battery_charging_current),
        )
        self._add("/Protocol/Charging", None)
        self._add("/Protocol/AcCharging", None)
        self._add("/Protocol/SccCharging", None)
        self._add("/Protocol/ReportedBatteryChargingCurrent", None)
        self._add("/Protocol/PvInputCurrentForBattery", None)
        self._add("/Protocol/PvChargingPower", None)
        if capabilities is not None:
            self._add(
                "/Settings/ChargeCurrentLimit",
                capabilities.total_limit,
                _format_value("A", 0),
            )
            self._add(
                "/Settings/UtilityChargeCurrentLimit",
                capabilities.utility_limit,
                _format_value("A", 0),
            )
            self._add(
                "/Capabilities/ChargeCurrentLimits",
                capabilities.selectable_total_limits_text,
            )
            self._add(
                "/Capabilities/UtilityChargeCurrentLimits",
                capabilities.selectable_utility_limits_text,
            )
        self._service.register()

    def _add(self, path, value=None, formatter=None):
        arguments = {}
        if formatter is not None:
            arguments["gettextcallback"] = formatter
        self._service.add_path(path, value, **arguments)

    def _set(self, path, value):
        self._service[path] = value

    def publish(self, status: Pi30Status) -> None:
        self._set("/Connected", 1)
        self._set("/Dc/0/Voltage", status.battery_voltage)
        self._set("/Protocol/Charging", int(status.charger_active))
        self._set("/Protocol/AcCharging", int(status.ac_charging))
        self._set("/Protocol/SccCharging", int(status.scc_charging))
        self._set(
            "/Protocol/ReportedBatteryChargingCurrent",
            status.reported_battery_charging_current,
        )
        self._set(
            "/Protocol/PvInputCurrentForBattery", status.pv_input_current_for_battery
        )
        self._set("/Protocol/PvChargingPower", status.pv_charging_power)
        if self.config.protocol.publish_battery_charging_current:
            current = status.reported_battery_charging_current
            self._set("/Dc/0/Current", current)
            # The PI30 PV power field is diagnostic only. Adding it here would
            # double count PV whenever the reported battery current is total.
            self._set("/Dc/0/Power", status.battery_voltage * current)
        else:
            self._set("/Dc/0/Current", None)
            self._set("/Dc/0/Power", None)
        # PI30 exposes charger-source flags, but not a charge-stage name.
        self._set(
            "/State",
            CHARGER_STATE_POWER_SUPPLY if status.charger_active else CHARGER_STATE_OFF,
        )
        self._set("/ErrorCode", 0)

    def disconnect(self) -> None:
        self._set("/Connected", 0)
        for path in (
            "/Dc/0/Voltage",
            "/Dc/0/Current",
            "/Dc/0/Power",
            "/State",
            "/ErrorCode",
            "/Protocol/Charging",
            "/Protocol/AcCharging",
            "/Protocol/SccCharging",
            "/Protocol/ReportedBatteryChargingCurrent",
            "/Protocol/PvInputCurrentForBattery",
            "/Protocol/PvChargingPower",
        ):
            self._set(path, None)
