import os
import sys
import tempfile
import types
import unittest

from voltronic_charger.config import load_config
from voltronic_charger.dbus_service import ChargerDbusService
from voltronic_charger.models import ChargeCurrentCapabilities
from voltronic_charger.parser import parse_qpigs_pi30
from tests.test_parser import DOCUMENTED_SHAPE, KING_II_FIRST_CAPTURE


class FakeVeDbusService:
    def __init__(self, name, bus=None, register=None):
        self.name = name
        self.values = {}
        self.registered = False

    def add_path(self, path, value=None, **_arguments):
        self.values[path] = value

    def register(self):
        self.registered = True

    def __setitem__(self, path, value):
        self.values[path] = value


def config_text(publish):
    return """[serial]
port=/dev/ttyUSB1
[protocol]
profile=pi30
publish_battery_charging_current={}
[device]
model=Voltronic King II 5000
custom_name=King II
device_instance=40
service_name=com.victronenergy.charger.voltronic_king2
[driver]
poll_interval=5
failure_threshold=3
""".format(str(publish).lower())


class DbusServiceTest(unittest.TestCase):
    def setUp(self):
        self.original_vedbus = sys.modules.get("vedbus")
        sys.modules["vedbus"] = types.SimpleNamespace(VeDbusService=FakeVeDbusService)

    def tearDown(self):
        if self.original_vedbus is None:
            sys.modules.pop("vedbus", None)
        else:
            sys.modules["vedbus"] = self.original_vedbus

    def _config(self, publish):
        handle = tempfile.NamedTemporaryFile("w", delete=False)
        try:
            handle.write(config_text(publish))
            handle.close()
            return load_config(handle.name)
        finally:
            os.unlink(handle.name)

    def test_publishes_current_and_derives_power_without_adding_pv_power(self):
        service = ChargerDbusService(
            self._config(True),
            protocol_id="PI30",
            inverter_model="KING-5000",
        )
        service.publish(parse_qpigs_pi30(DOCUMENTED_SHAPE))
        values = service._service.values
        self.assertEqual(1, values["/Connected"])
        self.assertEqual(52.4, values["/Dc/0/Voltage"])
        self.assertEqual(12.0, values["/Dc/0/Current"])
        self.assertAlmostEqual(628.8, values["/Dc/0/Power"])
        self.assertNotEqual(628.8 + 420, values["/Dc/0/Power"])
        self.assertEqual(11, values["/State"])
        self.assertEqual(0, values["/ErrorCode"])
        self.assertEqual(420, values["/Protocol/PvChargingPower"])
        self.assertEqual("PI30", values["/Protocol/Id"])
        self.assertEqual("KING-5000", values["/Protocol/Model"])

    def test_real_idle_capture_publishes_zero_current_power_and_off_state(self):
        service = ChargerDbusService(self._config(True))
        service.publish(parse_qpigs_pi30(KING_II_FIRST_CAPTURE))
        values = service._service.values
        self.assertEqual(0.0, values["/Dc/0/Current"])
        self.assertEqual(0.0, values["/Dc/0/Power"])
        self.assertEqual(0, values["/State"])
        self.assertEqual(0, values["/Protocol/Charging"])

    def test_current_publication_can_remain_disabled(self):
        service = ChargerDbusService(self._config(False))
        service.publish(parse_qpigs_pi30(DOCUMENTED_SHAPE))
        values = service._service.values
        self.assertIsNone(values["/Dc/0/Current"])
        self.assertIsNone(values["/Dc/0/Power"])

    def test_publishes_inverter_reported_current_limits_and_options(self):
        capabilities = ChargeCurrentCapabilities(
            utility_limit=30,
            total_limit=140,
            selectable_utility_limits=(2, 10, 20, 30),
            selectable_total_limits=(10, 20, 60, 80, 100, 120, 140),
        )
        service = ChargerDbusService(self._config(True), capabilities=capabilities)
        values = service._service.values
        self.assertEqual(140, values["/Settings/ChargeCurrentLimit"])
        self.assertEqual(30, values["/Settings/UtilityChargeCurrentLimit"])
        self.assertEqual(
            "10,20,60,80,100,120,140",
            values["/Capabilities/ChargeCurrentLimits"],
        )
        self.assertEqual(
            "2,10,20,30",
            values["/Capabilities/UtilityChargeCurrentLimits"],
        )

    def test_disconnect_invalidates_live_values(self):
        service = ChargerDbusService(self._config(True))
        service.publish(parse_qpigs_pi30(DOCUMENTED_SHAPE))
        service.disconnect()
        values = service._service.values
        self.assertEqual(0, values["/Connected"])
        for path in ("/Dc/0/Voltage", "/Dc/0/Current", "/Dc/0/Power", "/State"):
            self.assertIsNone(values[path])


if __name__ == "__main__":
    unittest.main()
