import unittest

from voltronic_charger.main import _identify, _read_charge_current_capabilities
from voltronic_charger.protocol import ProtocolError


class FakeClient:
    def __init__(self, responses):
        self.responses = responses
        self.commands = []

    def query(self, command):
        self.commands.append(command)
        response = self.responses[command]
        if isinstance(response, Exception):
            raise response
        return response


class MainIdentificationTest(unittest.TestCase):
    def test_live_identity_and_qvfw2_fallback(self):
        client = FakeClient(
            {
                "QPI": "(PI30",
                "QMN": "(KING-5000",
                "QID": "(96332108100916",
                "QVFW": ProtocolError("NAK"),
                "QVFW2": "(VERFW2:00000.00",
            }
        )
        self.assertEqual(
            {
                "protocol_id": "PI30",
                "inverter_model": "KING-5000",
                "serial_number": "96332108100916",
                "firmware": "VERFW2:00000.00",
            },
            _identify(client),
        )
        self.assertEqual(["QPI", "QMN", "QID", "QVFW", "QVFW2"], client.commands)

    def test_wrong_protocol_is_rejected_before_publication(self):
        client = FakeClient({"QPI": "(PI18"})
        with self.assertRaises(ProtocolError):
            _identify(client)

    def test_wrong_model_is_rejected_before_publication(self):
        client = FakeClient({"QPI": "(PI30", "QMN": "(OTHER"})
        with self.assertRaises(ProtocolError):
            _identify(client)

    def test_charge_current_capabilities_are_queried_from_inverter(self):
        client = FakeClient(
            {
                "QPIRI": (
                    "(230.0 21.7 230.0 50.0 21.7 5000 5000 48.0 46.0 "
                    "42.0 56.4 54.0 2 030 140 0 2 2 9 01 0 00 48.0 0 1 120"
                ),
                "QMCHGCR": "(010 020 060 080 100 120 140",
                "QMUCHGCR": "(002 010 020 030",
            }
        )
        capabilities = _read_charge_current_capabilities(client)
        self.assertEqual(30, capabilities.utility_limit)
        self.assertEqual(140, capabilities.total_limit)
        self.assertEqual(
            ["QPIRI", "QMCHGCR", "QMUCHGCR"],
            client.commands,
        )


if __name__ == "__main__":
    unittest.main()
