# Voltronic King II 5000 charger telemetry for Venus OS

This read-only driver exposes a Voltronic King II 5000 as an additional
`com.victronenergy.charger` service on Victron Venus OS / Cerbo GX.

The live target returned `QPI=PI30`, `QMN=KING-5000`, a complete serial number,
`QMOD=B`, and repeated CRC-valid classic 21-field `QPIGS` responses at 2400
baud. The first capture was disturbed by Venus `serial-starter`; clean replies
were received after making `/dev/ttyUSB1` exclusive.

The driver sends only allowlisted inquiry commands. It contains no inverter
setting commands.

## Published values

The D-Bus service defaults to
`com.victronenergy.charger.voltronic_king2` and publishes:

- `/Connected`: `1` after a valid response, otherwise `0` on disconnect.
- `/Dc/0/Voltage`: QPIGS battery voltage.
- `/Dc/0/Current`: QPIGS reported battery charging current.
- `/Dc/0/Power`: battery voltage multiplied by reported charging current.
- `/State`: `0` while inactive and `11` while a charging flag or positive
  charging current is present. PI30 does not expose Bulk/Absorption/Float.
- `/ErrorCode`: `0` for a valid sample.
- `/Settings/ChargeCurrentLimit`: current total charging-current limit from
  `QPIRI`.
- `/Settings/UtilityChargeCurrentLimit`: current utility charging-current
  limit from `QPIRI`.
- `/Capabilities/ChargeCurrentLimits`: comma-separated values returned by
  `QMCHGCR`.
- `/Capabilities/UtilityChargeCurrentLimits`: comma-separated values returned
  by `QMUCHGCR`.
- `/Protocol/*`: protocol identity, model, charging flags, reported current,
  PV current, and PV charging power for diagnostics.

`/Protocol/PvChargingPower` is not added to `/Dc/0/Power`. Standard charger
power is calculated exactly once from battery voltage and charging current, so
the separate PV token cannot be counted twice.

In the currently observed Battery mode with no charging, the expected values
are approximately `52.50 V`, `0 A`, `0 W`, `/State=0`, and `/ErrorCode=0`.

## Cerbo installation

Requirements:

- Venus OS with `/usr/bin/python3`, `serial`, `dbus`, and `gi` modules.
- Victron `velib_python` under the standard `dbus-systemcalc-py` path.
- runit tools (`svc`, `svstat`, and `multilog`).
- The Voltronic adapter connected at the serial path configured below.

For the confirmed system:

- Venus OS: `v3.80`.
- Application directory: `/data/apps/dbus-voltronic-charger`.
- Current inverter port: `/dev/ttyUSB1`.
- Adapter: CH340/CH341 family, VID:PID `1a86:7523`.
- Stable physical path observed as
  `/dev/serial/by-path/platform-1c1c000.usb-usb-0:1.2:1.0-port0`.

Extract the release archive into a temporary directory and run:

```sh
cd /data/dbus-voltronic-charger-0.3.0
chmod +x install.sh activate.sh deactivate.sh uninstall.sh serial-port.sh
./install.sh
```

The installer copies files to `/data/apps/dbus-voltronic-charger`, backs up an
existing inactive installation, preserves an existing `config.ini`, and leaves
the service inactive.

Edit the installed configuration:

```sh
vi /data/apps/dbus-voltronic-charger/config.ini
```

Use these confirmed values:

```ini
[serial]
port = /dev/ttyUSB1
baudrate = 2400
timeout = 2.0
command_delay = 0.5

[protocol]
profile = pi30
publish_battery_charging_current = true
```

`serial.port` is required and never silently defaults to another port. A
verified `by-path` link may replace `/dev/ttyUSB1` later.

Set `device_instance` to an unused charger-class number. Inspect existing
charger services on the Cerbo before choosing it:

```sh
dbus -y | grep 'com.victronenergy.charger' || true
```

For each listed service, read its instance:

```sh
dbus -y SERVICE_NAME /DeviceInstance GetValue
```

Do not activate until `device_instance` is filled in.

## Pre-activation test

The one-shot check opens only the configured port, validates identity, reads
the current-limit capabilities and one `QPIGS` sample, prints one JSON object,
and exits without registering on D-Bus:

```sh
cd /data/apps/dbus-voltronic-charger
PYTHONPATH=. /usr/bin/python3 -m voltronic_charger.main \
  --config ./config.ini --once
```

## Activation and serial ownership

Activate only after the configuration and one-shot result are correct:

```sh
cd /data/apps/dbus-voltronic-charger
./activate.sh --confirm-pi30
svstat /service/dbus-voltronic-charger
tail -f /var/log/dbus-voltronic-charger/current
```

Before each service start, `serial-port.sh acquire` resolves the configured
path to its real tty basename and calls Venus `stop-tty.sh` for that tty only.
It has a 15-second watchdog. It does not stop global `serial-starter`, does not
contain a Pylontech port, and does not touch other USB adapters.

At startup the driver requires live `QPI=PI30` and `QMN=KING-5000`. It reads
`QID`, tries `QVFW`, and falls back to `QVFW2` because this inverter returns a
valid `NAK` to `QVFW` and `VERFW2:00000.00` to `QVFW2`. It then reads `QPIRI`,
`QMCHGCR`, and `QMUCHGCR`. Current limits and selectable values are never
hard-coded, so each supported inverter describes its own capabilities.

The limit paths are read-only in version `0.3.0`. Changing current requires a
separate, explicitly enabled control layer because it changes inverter
settings. That layer must validate every requested value against the live
`QMCHGCR` or `QMUCHGCR` list before sending a setting command.

## Live verification

Check the service directly:

```sh
dbus -y com.victronenergy.charger.voltronic_king2 /Connected GetValue
dbus -y com.victronenergy.charger.voltronic_king2 /Dc/0/Voltage GetValue
dbus -y com.victronenergy.charger.voltronic_king2 /Dc/0/Current GetValue
dbus -y com.victronenergy.charger.voltronic_king2 /Dc/0/Power GetValue
dbus -y com.victronenergy.charger.voltronic_king2 /State GetValue
dbus -y com.victronenergy.charger.voltronic_king2 /ErrorCode GetValue
dbus -y com.victronenergy.charger.voltronic_king2 /Settings/ChargeCurrentLimit GetValue
dbus -y com.victronenergy.charger.voltronic_king2 /Settings/UtilityChargeCurrentLimit GetValue
dbus -y com.victronenergy.charger.voltronic_king2 /Capabilities/ChargeCurrentLimits GetValue
dbus -y com.victronenergy.charger.voltronic_king2 /Capabilities/UtilityChargeCurrentLimits GetValue
```

Confirm that the device is also visible in the Venus device list. During the
current non-charging Battery mode, current and power should remain zero rather
than invalid or fabricated.

When charging becomes available, compare `/Dc/0/Current` with the inverter
display under AC-only, PV-only, and combined charging. No configuration change
is needed to collect those observations.

## Deactivation, update, and rollback

Deactivate while preserving the application and configuration:

```sh
/data/apps/dbus-voltronic-charger/deactivate.sh
```

This stops only the owned service, removes only its boot hook, and returns the
configured tty to Venus `serial-starter` through `start-tty.sh`.

For an update, deactivate first and run the new archive's `install.sh`. The
installer creates a timestamped backup of the existing application directory
and preserves `config.ini`.

Uninstall recoverably:

```sh
/data/apps/dbus-voltronic-charger/uninstall.sh
```

The uninstaller moves the application to a timestamped `.removed.*` directory
and prints the rollback command. It performs no recursive deletion.

## Development verification

```sh
python3 -m unittest discover -s tests -v
sh -n install.sh activate.sh deactivate.sh uninstall.sh serial-port.sh \
  service/run service/log/run
```

The current suite contains 34 tests covering protocol framing, the real King II
capture, dynamic current-limit discovery, serial pacing, configuration,
identity validation, D-Bus publication, double-count prevention, and packaging
safety.

## Protocol evidence

The framing and 21-field layout follow Voltronic's official AXPERT
KS/MKS/V PI30 communication protocol. The live King II response, rather than
the model name alone, is used to confirm this profile.

The same document defines `QPIRI` fields 14 and 15 as the current utility and
total charging-current settings, and defines `QMCHGCR` and `QMUCHGCR` as the
inverter-provided selectable-value inquiries. The driver parses those replies
at runtime instead of assuming a model-specific list.

Victron `dbus-systemcalc-py` consumes charger voltage and current and derives
charger power as voltage multiplied by current. This driver publishes the same
single battery-side power relationship and retains PV-specific telemetry only
under diagnostic `/Protocol/*` paths.
