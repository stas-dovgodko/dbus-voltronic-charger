"""Voltronic AC charger telemetry and guarded control bridge."""

__version__ = "0.5.0"
