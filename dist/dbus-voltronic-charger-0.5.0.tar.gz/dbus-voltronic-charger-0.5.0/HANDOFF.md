# Development handoff

## Confirmed target

- Inverter: Voltronic King II 5000.
- Venus OS: `v3.80` on Cerbo GX.
- Application path: `/data/apps/dbus-voltronic-charger`.
- Configured serial port: `/dev/ttyUSB1`, required and configurable.
- Adapter: CH340/CH341 family `1a86:7523`.
- Observed by-path link:
  `/dev/serial/by-path/platform-1c1c000.usb-usb-0:1.2:1.0-port0`.
- Pylontech remains on a separate PL2303 adapter at `/dev/ttyUSB0` and must not
  be touched by this driver.

## Serial conflict and resolution

The initial probe was disturbed by Venus services competing for
`/dev/ttyUSB1`. `rgps_dbus` was observed holding the port, and the normal
`dbus-cgwacs`, `gps-dbus`, and `vedirect-interface` ttyUSB1 service supervisors
were present.

On Venus OS v3.80, `/opt/victronenergy/serial-starter/stop-tty.sh` resolves a
tty argument, removes only `/dev/serial-starter/<tty>`, and stops services
matching only that tty. The confirmed invocation is:

```sh
/opt/victronenergy/serial-starter/stop-tty.sh ttyUSB1
```

The image has no `timeout` command. The project therefore includes
`serial-port.sh`, which resolves `serial.port`, invokes `stop-tty.sh` or
`start-tty.sh` with the tty basename, and applies a 15-second POSIX-shell
watchdog. It contains no hard-coded ttyUSB0 or ttyUSB1 target; the configured
port is the only target.

After stopping ttyUSB1:

- `fuser /dev/ttyUSB1` returned no owner.
- All three ttyUSB1 services were down.
- `/dev/serial-starter/ttyUSB1` was absent.
- Pylontech and other ports were untouched.

## Clean live protocol capture

After the port became exclusive, every requested frame was complete and
CRC-valid except for the protocol-valid `NAK` response to `QVFW`:

- `QPI`: `PI30`.
- `QMN`: `KING-5000`.
- `QID`: `96332108100916`.
- `QVFW`: `NAK`.
- `QVFW2`: `VERFW2:00000.00`.
- `QMOD`: `B`.
- `QPIGS`: classic 21-field response:

  ```text
  (000.0 00.0 229.9 50.0 0002 0002 000 365 52.50 000 073 0043 0000 000.0 00.00 00000 00010000 00 00 00000 010
  ```

The inverter was running from the battery and was not charging. The sample
therefore reported `52.50 V`, `0 A` charging current, `0 W` PV charging power,
and inactive AC/SCC charging flags.

## Driver policy

The user explicitly selected full charger publication based on the confirmed
PI30 layout:

- `/Dc/0/Voltage` is QPIGS battery voltage.
- `/Dc/0/Current` is QPIGS reported battery charging current only when it is
  attributable to AC-only charging.
- `/Dc/0/Power` is calculated once as voltage multiplied by that current.
- QPIGS PV charging power remains diagnostic and is never added to standard
  charger power, preventing double counting.
- Simultaneous AC+SCC charging invalidates standard current and power because
  PI30 does not report the split; this prevents double counting PV as AC charge.
- `/State` is `0` when AC charging is inactive and `3` when AC charging is
  active. PI30 does not justify reporting Absorption or Float.
- `/Mode` follows the standard charger values `1=On`, `4=Off` and reflects the
  QPIRI charger-source priority.
- QPIGS AC-input V/Hz and AC-output V/Hz/W/VA/load are published on the same
  `com.victronenergy.charger` service. No grid or genset service is created.
- `/ErrorCode` is `0` for a valid sample.

At startup the service requires live `PI30` and `KING-5000` identity responses.
It falls back from `QVFW` to `QVFW2` for firmware identification.

## Packaging and activation

Version `0.5.0` includes:

- configurable serial command pacing;
- full voltage/current/power/state/error publication;
- protocol/model validation;
- dynamic `QPIRI`, `QMCHGCR`, and `QMUCHGCR` charge-current capability
  discovery with no hard-coded current values;
- opt-in current-limit control restricted to live selectable values, with ACK
  and QPIRI read-back verification;
- opt-in `/Mode` control: Off selects solar-only charging and On restores a
  known non-solar-only charger-source priority, with ACK and QPIRI read-back;
- AC input/output telemetry from QPIGS on the charger service;
- `QVFW2` firmware fallback;
- per-configured-port serial-starter acquire/release lifecycle;
- 52 unit tests plus POSIX syntax checks.

The installer preserves an existing `config.ini`, so an upgraded Cerbo must be
checked for these values before activation:

```ini
port = /dev/ttyUSB1
profile = pi30
publish_battery_charging_current = true
allow_current_limit_writes = false
allow_mode_writes = false
enabled_charger_source_priority =
device_instance = <unused charger-class instance>
```

Activation remains explicit:

```sh
./activate.sh --confirm-pi30
```

Do not push or commit without an explicit user request. Preserve all existing
working-tree changes.

## Remaining live validation

The idle response is sufficient to run and observe the complete D-Bus device,
but charging attribution still needs comparison when the battery eventually
accepts charge:

- AC-only charging;
- PV-only charging;
- combined AC and PV charging;
- inverter display current versus `/Dc/0/Current`.

No inverter setting command is needed for these checks. Current-limit and Mode
writes remain separate explicit opt-ins.

## Charge-current control boundary

The driver now reads the current utility and total charge limits from `QPIRI`
and the allowed choices from `QMUCHGCR` and `QMCHGCR`. It publishes both the
current settings and the inverter-provided option lists on D-Bus. This is the
universal capability source; no model-specific list is embedded in the code.

Version `0.5.0` implements the writable control layer but keeps it disabled by
default. With `allow_current_limit_writes=false`, the paths are read-only and
the runtime sends no setting commands. When explicitly enabled, a write is
accepted only from the corresponding live option list, must receive `ACK`, and
must be confirmed by `QPIRI` before D-Bus reports success.

The live King II reported total choices `10,20,...,100 A`, utility choices
`2,10,20,...,100 A`, and current settings `60 A` for both. The running v0.3.0
service published `Connected=1`, `49.7 V`, `0 A`, `0 W`, `State=0`, and held
`/dev/ttyUSB1` exclusively through its Python process.

## AC charger D-Bus model

The official `com.victronenergy.charger` model includes `/NrOfOutputs`,
`/Dc/0/*`, `/State`, `/Mode`, `/ErrorCode`, `/Ac/In/L1/I`, `/Ac/In/L1/P`, and
`/Ac/In/CurrentLimit`. The King PI30 QPIGS response provides AC-input voltage
and frequency plus AC-output voltage, frequency, active/apparent power and load,
but not measured AC-input current or power. The driver therefore publishes the
available values under `/Ac/In/L1/V`, `/Ac/In/L1/F`, and `/Ac/Out/L1/*`, and
does not fabricate `/Ac/In/L1/I`, `/Ac/In/L1/P`, or `/Ac/In/CurrentLimit`.

The existing `/Settings/ChargeCurrentLimit` and
`/Settings/UtilityChargeCurrentLimit` paths are documented driver extensions
for battery-side DC limits. They are not Victron AC-input current-limit paths.
QPIGS heatsink temperature is not published as `/Dc/0/Temperature`, because the
official charger model defines that path as battery temperature.
